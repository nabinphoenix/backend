# """
# Find a pair with the given sum in an array. Given an unsorted integer array, print a pair 
# with the given sum in it. 
# """

def find_pair_with_sum(lst, target):
    found = 0
    for i in range(len(lst)):
        for j in range(i+1,len(lst)):
            if lst[i] + lst[j] == target:
                found = 1
                print(f"Pair found({lst[i]}, {lst[j]})")
    if found==0:
         print("No Pairs found")

numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9]
target = 10
find_pair_with_sum(numbers, target)
