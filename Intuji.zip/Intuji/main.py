import os
from fastapi import FastAPI, HTTPException, Path
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List
from pymongo import MongoClient, ReturnDocument
from fastapi.encoders import jsonable_encoder
from dotenv import load_dotenv

# 1) Load environment variables
load_dotenv()
MONGODB_URL = os.getenv("MONGODB_URL")

# 2) Connect to MongoDB
t_client = MongoClient(MONGODB_URL)
db = t_client["blog_database"]
blogs = db["blogs"]
counters = db["counters"]

# 3) Ensure our counter doc exists at startup
if counters.find_one({"_id": "blogid"}) is None:
    counters.insert_one({"_id": "blogid", "seq": 0})

# 4) FastAPI app
app = FastAPI()
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # in prod, narrow this down
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# 5) Pydantic models (id is int)
class Blog(BaseModel):
    title: str
    description: str
    category: str

class BlogInDB(Blog):
    id: int

# 6) Helper to fetch next integer ID
def get_next_blog_id() -> int:
    counter = counters.find_one_and_update(
        {"_id": "blogid"},
        {"$inc": {"seq": 1}},
        return_document=ReturnDocument.AFTER
    )
    return counter["seq"]

# 7) CRUD Endpoints
@app.get("/blogs", response_model=List[BlogInDB])
async def get_all_blogs():
    docs = list(blogs.find().sort("_id", 1))
    return [
        {"id": doc["_id"], **{k: doc[k] for k in ["title", "description", "category"]}}
        for doc in docs
    ]

@app.get("/blogs/{blog_id}", response_model=BlogInDB)
async def get_blog_by_id(blog_id: int = Path(..., ge=1)):
    doc = blogs.find_one({"_id": blog_id})
    if not doc:
        raise HTTPException(status_code=404, detail="Blog not found")
    return {"id": doc["_id"], "title": doc["title"], "description": doc["description"], "category": doc["category"]}

@app.post("/blogs", response_model=BlogInDB, status_code=201)
async def create_blog(blog: Blog):
    new_id = get_next_blog_id()
    data = jsonable_encoder(blog)
    blogs.insert_one({"_id": new_id, **data})
    return {"id": new_id, **data}

@app.put("/blogs/{blog_id}", response_model=BlogInDB)
async def update_blog(
    blog_id: int = Path(..., ge=1),
    blog: Blog = None
):
    data = jsonable_encoder(blog)
    result = blogs.update_one({"_id": blog_id}, {"$set": data})
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="Blog not found")
    return {"id": blog_id, **data}

@app.delete("/blogs/{blog_id}", response_model=dict)
async def delete_blog(blog_id: int = Path(..., ge=1)):
    result = blogs.delete_one({"_id": blog_id})
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Blog not found")
    return {"message": "Blog deleted successfully"}

@app.get("/")
async def root():
    return {"message": "Welcome to the Blog API with numeric IDs!"}
# 8) Run the app with: uvicorn main:app --reload
# Ensure you have the required packages installed: fastapi, pymongo, python-dotenv, pydantic, uvicorn
# You can test the API using tools like Postman or curl.
# Ensure MongoDB is running and the MONGODB_URL is set correctly in your .env file.
# Example .env file content: